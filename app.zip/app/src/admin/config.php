<?php
$conn=mysqli_connect("localhost", "id19369351_saukicare", "y^P88qFAnu986Es", "id19369351_sauki");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  date_default_timezone_set("Africa/Lagos"); 
?>